===========================
crcmod-osx gsutil mirror
===========================
Unofficial crcmod (https://bitbucket.org/cmcqueen1975/crcmod) compiled for OS X.
This respository may disappear, so do not depend on it.

-------
License
-------

The ``crcmod`` package is released under the MIT license. See the ``LICENSE``
file for details.

------------
Contributors
------------

Craig McQueen
