oauth2client.contrib.xsrfutil module
====================================

.. automodule:: oauth2client.contrib.xsrfutil
    :members:
    :undoc-members:
    :show-inheritance:
